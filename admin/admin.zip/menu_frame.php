<html>
<head>
<style type="text/css">
td a {text-decoration:none; color: #FFCC00; font-style:normal; font-size:11px }
td a:hover {color: #03617C; text-decoration:underline}
td { text-align:justify ; padding-left:12px;}
th { text-align:justify ; color:#03617C ;  padding-left:8px;}
th  a { text-decoration:none; text-align:justify ; color:#03617C}
</style>
<link href="img/style.css" rel="stylesheet" type="text/css">
<script src="cms_js/jquery.js" type="text/javascript"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
.style80 {font-size: 12px}
-->
</style><title>Control Panel : AIHEEE</title></head>
<body>
<table width="100%" border="0" bgcolor="#03617C">
  <tr>
    <td height="83">&nbsp;</td>
  </tr>
</table>
<table width="234" cellpadding="0" cellspacing="0">

<tr>
  <th class="style2">&nbsp;</th>
</tr>
<tr>
  <th height="20" class="style2"><a  href="#" onClick="parent.content.location.href='content_frame.php'; return false;">Admin Home</a></th>
</tr>
<!--<tr>
  <th class="style2"><a href="#" id="memberOptionsAnchor" onClick="return showMemberOptions();">Product Management</a></th>
</tr>-->


<tr>
      <td><a  href="#" onClick="parent.content.location.href='homepage.php'; return false;" style="font-size:16px">Manage Home Pages </a></td>
    </tr>
<tr>
      <td><a  href="#" onClick="parent.content.location.href='informative_view.php'; return false;" style="font-size:16px">Manage Informative Pages </a></td>
    </tr>
 <tr>
      <td><a  href="#" onClick="parent.content.location.href='gallary_view.php'; return false;" style="font-size:16px">Manage Gallery</a></td>
    </tr>
	 <tr>
      <td><a  href="#" onClick="parent.content.location.href='city_view.php'; return false;" style="font-size:16px">Manage Contact Us</a></td>
    </tr>
	 <tr>
      <td><a  href="#" onClick="parent.content.location.href='hotdeal_view.php'; return false;" style="font-size:16px">Manage Downloads</a></td>
    </tr>

<!-- <tr>
 <td class="style2"><table id="memberOptions">
       -->
  <!--  <tr>
      <td><a  href="#" onClick="parent.content.location.href='web_category_view.php'; return false;">Manage Category</a></td>
    </tr>
	<tr>
      <td><a  href="#" onClick="parent.content.location.href='web_subcategory_view.php'; return false;">Manage Subcategory</a></td>
    </tr>
	-->
	<!--<tr>
      <td><a  href="#" onClick="parent.content.location.href='gallary_view.php'; return false;">Manage Destination</a></td>
    </tr>
	<tr>
      <td><a  href="#" onClick="parent.content.location.href='hotdeal_view.php'; return false;">Manage Tour Packages</a></td>
    </tr>-->
	
	

    <!--   <tr>
      <td><a  href="#" onClick="parent.content.location.href='video_view.php'; return false;">Manage New Agent </a></td>
    </tr> 
    
      <tr>
      <td><a  href="#" onClick="parent.content.location.href='clients_view.php'; return false;">Manage Agents</a></td>
      </tr>

	<tr>
      	<tr>
      <td><a  href="#" onClick="parent.content.location.href='web_ourclients_view.php'; return false;">Manage Registrations</a></td>
    </tr>-->
     <!-- <tr>
      <td><a  href="#" onClick="parent.content.location.href='video_view.php'; return false;">Manage Video</a></td>
    </tr>
      
	<tr>
      <td><a  href="#" onClick="parent.content.location.href='hotdeal_view.php'; return false;">Manage Knowledge Bank Pdf</a></td>
    </tr>
	-->
	
	
  </table></td>
</tr>

<!--<tr>
  <th class="style2"><a href="#" id="memberOptionsAnchor" onClick="return showMemberOptions();">Website Menu </a></th>
</tr>
<tr>
  <td class="style2"><table id="memberOptions">
   
	
	
  </table></td>
</tr>-->
<tr><td height="20" class="style2"><a  href="#" class="style2" onClick="parent.content.location.href='web_changepw.php'; return false;">Change Password</a></td></tr>
<tr><td height="20" class="style2"><a  href="#" class="style2" onClick="parent.location.href='logout.php'; return false;">Logout</a></td>
</tr>
</table>
</body>
</html>