<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Admin Panel : AIHEEE</title>
<script>
if(window != top)
{
top.location.href='home.php'
}
</script>
</head>

<frameset cols="18%,*"   border="0" frameborder="0" framespacing="0">
<frame src="menu_frame.php" id="menu" name="menu"  noresize="noresize" scrolling="no"   />

		<frameset rows="15%,*"  border="0" frameborder="0" framespacing="0" >
		<frame src="header_frame.php"   id="header"  name="header"  noresize="noresize" scrolling="no"  />
		<frame src="content_frame.php"  name="content" scrolling="yes"    id="content"  />
  </frameset>
</frameset><noframes></noframes>
</html>
